test = {
  'hidden': False,
  'name': '0.1',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> circuits_midterm_var > 172 and circuits_midterm_var < 174
          True
          >>> spanish_midterm_var > 83 and spanish_midterm_var < 85
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}