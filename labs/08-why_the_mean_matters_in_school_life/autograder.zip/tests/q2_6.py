test = {
  'hidden': False,
  'name': '2.6',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> # As the confidence increases, what happens to the size of the interval?
          >>> statement_1
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> # Does sampling from the population with replacement make sense
          >>> # if our goal is to get a better picture of the population?
          >>> statement_2
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> # As the confidence increases, what happens to the size of the interval?
          >>> statement_3
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> # Can we do this?
          >>> statement_4
          False
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}