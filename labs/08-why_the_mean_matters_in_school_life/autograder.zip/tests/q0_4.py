test = {
  'hidden': False,
  'name': '0.4',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> cathy_proportion > 0.95 and cathy_proportion < 0.96
          True
          >>> sam_proportion > 0.58 and sam_proportion < 0.59
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}