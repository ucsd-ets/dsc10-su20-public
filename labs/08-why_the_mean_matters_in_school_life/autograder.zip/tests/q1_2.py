test = {
  'hidden': False,
  'name': '1.2',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> # Make sure you fill in the answer...
          >>> q1_2 != []
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> # Remember that the mean is strongly influenced by extreme values.
          >>> q1_2 != [2, 1, 3]
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> q1_2 != [3, 2, 1]
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> q1_2 == [1, 2, 3]
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}