test = {
  'hidden': False,
  'name': '2.4',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> population_sd > 0.4 and population_sd < 0.5
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}