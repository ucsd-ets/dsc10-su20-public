test = {
  'hidden': False,
  'name': '0.3',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> cathy_su > 1 and cathy_su < 2
          True
          >>> sam_su > 0 and sam_su < 0.5
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}