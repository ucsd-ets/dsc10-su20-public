test = {
  'hidden': False,
  'name': '2.5',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> req_sample_size > 26000 and req_sample_size < 27500
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}