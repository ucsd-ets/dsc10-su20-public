test = {
  'hidden': False,
  'name': '0.2',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> circuits_midterm_sd > 12 and circuits_midterm_sd < 14
          True
          >>> spanish_midterm_sd > 8 and spanish_midterm_sd < 10
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}